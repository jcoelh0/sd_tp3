/**
* This package contains the Mechanic Interfaces: IMechanicL, IMechanicP, IMechanicRA.
*/

package entities.Mechanic.Interfaces;
