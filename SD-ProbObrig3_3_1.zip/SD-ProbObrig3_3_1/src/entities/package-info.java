/**
* This package contains the entities that are part of the problem: Customers, Manager and the Mechanics.
*/

package entities;
