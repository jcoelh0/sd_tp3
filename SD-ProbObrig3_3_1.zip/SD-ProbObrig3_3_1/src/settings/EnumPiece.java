package settings;

/**
 *
 * @author Andre e Joao
 */
public enum EnumPiece {

	/**
	 *
	 */
	Engine,

	/**
	 *
	 */
	Brakes,

	/**
	 *
	 */
	Wheels
}
