/**
* Package that contains the Lounge and associated classes.
*
* - Lounge.java
* - LoungeServer.java
*/

package shared.Lounge;
