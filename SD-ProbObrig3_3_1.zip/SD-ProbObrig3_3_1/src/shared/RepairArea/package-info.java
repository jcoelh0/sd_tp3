/**
* Package that contains the RepairArea and associated classes.
*
* - RepairArea.java
* - RepairAreaServer.java
*/

package shared.RepairArea;
