/**
* Package that contains the OutsideWorld and associated classes.
*
* - OutsideWorld.java
* - OutsideWorldServer.java
*/

package shared.OutsideWorld;
