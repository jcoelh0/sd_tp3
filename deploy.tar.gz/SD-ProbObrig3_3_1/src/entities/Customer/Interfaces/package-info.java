/**
* This package contains the Customer Interfaces: ICustomerL, ICustomerOW, ICustomerP.
*/

package entities.Customer.Interfaces;
