/**
* This package contains the Mechanic States.
*/

package entities.Mechanic.States;
