/**
* Package that contains the constants variables.
* 
* - Constants.java 
* - EnumPiece.java
* - Piece.java
*/

package settings;
