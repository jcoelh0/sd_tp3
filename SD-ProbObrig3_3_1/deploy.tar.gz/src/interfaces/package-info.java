/**
 *  Interfaces to remote objects.<p>
 *  Back engine application: code is moved and executed in a platform supposed to be more powerful.
 *  Communication is based in Java RMI.
 */

package interfaces;
