/**
* Package that contains the SupplierSite and associated classes.
*
* - SupplierSite.java
* - SupplierSiteServer.java
*/

package shared.SupplierSite;
