/**
* This package contains the Manager Interfaces: IManagerL, IManagerOW, IManagerP. IManagerRA, IManagerSS.
*/

package entities.Manager.Interfaces;
