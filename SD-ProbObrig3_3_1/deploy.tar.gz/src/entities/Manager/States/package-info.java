/**
* This package contains the Manager States.
*/

package entities.Manager.States;
