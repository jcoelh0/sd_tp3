/**
* This package contains the manager: Manager.java, ManagerRun.java, package Interfaces and package States
*/

package entities.Manager;
